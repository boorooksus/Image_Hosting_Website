let express = require("express");
let app = express();
//let IdRouter = require('./Test01/server');

app.listen(3000, function(){
    console.log("App is running on port 3000");
});

app.use('/process', IdRouter);

app.get("/", function(req, res){
    res.sendfile("login2.html");
});

/*
app.get("/addUser2.html", function(req, res){
    res.sendfile("addUser2.html");
});
*/
